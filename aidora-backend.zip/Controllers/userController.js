const User = require('../Models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();


exports.registerUser = async (req, res) => {
    const { firstName, lastName, nic, email, password, phoneNumberCountryCode, phoneNumberRest, address } = req.body;

    try {
        // Check if user already exists
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }

        
        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        console.log("Original Password:", password);
        console.log("Hashed Password during registration:", hashedPassword);


        // Create new user
        const newUser = new User({
            firstName,
            lastName,
            nic,
            email,
            password: hashedPassword,
            phoneNumber: {
                countryCode: phoneNumberCountryCode,
                number: phoneNumberRest
            },
            address
        });

        const savedUser = await newUser.save();

        // Create JWT token
        const token = jwt.sign({ id: savedUser._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.status(201).json({ token });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};




exports.loginUser = async (req, res) => {
    const { email, password } = req.body;
console.log("login user called");
    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: 'User not found' });

        const isPasswordCorrect = await bcrypt.compare(password, user.password);
        if (!isPasswordCorrect) return res.status(400).json({ message: 'Invalid credentials' });

        const token = jwt.sign({ email: user.email, id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.status(200).json({ result: user, token });
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};



//adminlogin

// Simulate sending OTP
let generatedOtp = null;



exports.loginAdmin = async (req, res) => {
    const { email, password } = req.body;

    try {
        console.log("Email: ", email);
        const user = await User.findOne({ email });
        if (!user) {
            console.log("User not found");
            return res.status(400).json({ message: 'User not found' });
        }

        console.log("User found:", user);
        console.log("Provided password:", password);
        console.log("Stored hashed password:", user.password);

        const isPasswordCorrect = await bcrypt.compare(password, user.password);
        if (!isPasswordCorrect) {
            console.log("Incorrect password");
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        if (user.role !== 'admin') {
            console.log("Not an admin");
            return res.status(403).json({ message: 'Access denied. Admins only.' });
        }

        const otp = crypto.randomInt(100000, 999999).toString();
        otpStore[email] = otp;
        console.log(`OTP for user ${email} is ${otp}`);

        res.status(200).json({ message: 'OTP sent to email.', otpSent: true });
    } catch (error) {
        console.error("Error: ", error);
        res.status(500).json({ message: 'Something went wrong' });
    }
};





// exports.loginAdmin = async (req, res) => {
//     const { email, password } = req.body;
// console.log("loginAdmin called");
//     try {
//         const user = await User.findOne({ email });
//         if (!user || user.role !== 'admin') {
//             return res.status(400).json({ message: 'Invalid credentials' });
//         }

//         const isPasswordCorrect = await bcrypt.compare(password, user.password);
//         if (!isPasswordCorrect) {
//             return res.status(400).json({ message: 'Invalid credentials' });
//         }

//         // Generate OTP
//         generatedOtp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
//         console.log('Generated OTP:', generatedOtp); // In a real app, send this via email/SMS

//         res.status(200).json({ message: 'OTP sent' });
//     } catch (error) {
//         res.status(500).json({ message: 'Something went wrong' });
//     }
// };





exports.verifyOtp = async (req, res) => {
    const { email, otp } = req.body;

    try {
        if (otp !== generatedOtp) {
            return res.status(400).json({ message: 'Invalid OTP' });
        }

        const user = await User.findOne({ email });
        const token = jwt.sign({ email: user.email, id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.status(200).json({ token });
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};


//admin signup

exports.registerAdmin = async (req, res) => {
    const { firstName, lastName, nic, email, password, phoneNumberCountryCode, phoneNumberRest, address } = req.body;

    try {
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        console.log("Original Password:", password);
        console.log("Hashed Password during registration:", hashedPassword);


        const newUser = new User({
            firstName,
            lastName,
            nic,
            email,
            password,
            phoneNumber: {
                countryCode: phoneNumberCountryCode,
                number: phoneNumberRest
            },
            address,
            role: 'admin'  // Set role to 'admin'
        });

        const savedUser = await newUser.save();
        console.log("admin saved");

        const token = jwt.sign({ id: savedUser._id, role: savedUser.role }, process.env.JWT_SECRET, { expiresIn: '1h' });


        res.status(201).json({ token });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};



//   admin profile

exports.updateAdminProfile = async (req, res) => {
    const { firstName, lastName, email, phoneNumber, address } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'Admin not found' });
        }

        user.firstName = firstName || user.firstName;
        user.lastName = lastName || user.lastName;
        user.phoneNumber.countryCode = phoneNumber.countryCode || user.phoneNumber.countryCode;
        user.phoneNumber.number = phoneNumber.number || user.phoneNumber.number;
        user.address = address || user.address;

        await user.save();
        res.status(200).json({ message: 'Profile updated successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

// Change Admin Password
exports.changeAdminPassword = async (req, res) => {
    const { email, currentPassword, newPassword } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'Admin not found' });
        }

        const isMatch = await bcrypt.compare(currentPassword, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Incorrect current password' });
        }

        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(newPassword, salt);

        await user.save();
        res.status(200).json({ message: 'Password changed successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};